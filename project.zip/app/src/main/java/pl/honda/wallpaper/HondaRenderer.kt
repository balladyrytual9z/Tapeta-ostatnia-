package pl.honda.wallpaper

import android.content.Context
import android.graphics.BitmapFactory
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.GLUtils
import android.os.SystemClock
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Calendar
import java.util.Random
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

class HondaRenderer(private val ctx: Context) : GLSurfaceView.Renderer {

    private var program = 0
    private var texImage = 0
    private var texNoise = 0
    private var texLights = 0
    private var texMoon = 0
    private var imgW = 1280
    private var imgH = 720
    private var surfW = 1
    private var surfH = 1
    private val startMs = SystemClock.elapsedRealtime()

    private val quad = ByteBuffer.allocateDirect(8 * 4).order(ByteOrder.nativeOrder())
        .asFloatBuffer().apply {
            put(floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f)); position(0)
        }

    private var aPos = 0
    private var uTex = 0; private var uNoise = 0; private var uLights = 0; private var uMoonTex = 0
    private var uTexel = 0; private var uCover = 0; private var uFlow = 0
    private var uSweep = 0; private var uPulse = 0; private var uStar = 0
    private var uSun = 0; private var uAlt = 0; private var uMoon = 0; private var uShoot = 0

    // słońce i księżyc (pozycja na ekranie 0..1, wysokość nad horyzontem -1..1)
    private var sunX = 0.88f; private var sunY = 0.78f; private var sunAlt = 0f
    private var moonX = 0.5f; private var moonY = 0.9f; private var moonE = 0f; private var moonAlt = -1f
    private var lastSunMs = -100000L

    // spadająca gwiazda
    private val rnd = Random()
    private var shootStart = -1f; private var nextShoot = 12f
    private var shootX = 0.5f; private var shootY = 0.2f; private var shootAng = 0.6f

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        program = buildProgram(VERTEX, FRAGMENT)
        aPos = GLES20.glGetAttribLocation(program, "aPos")
        fun u(n: String) = GLES20.glGetUniformLocation(program, n)
        uTex = u("uTex"); uNoise = u("uNoise"); uLights = u("uLights"); uMoonTex = u("uMoonTex")
        uTexel = u("uTexel"); uCover = u("uCover"); uFlow = u("uFlow")
        uSweep = u("uSweep"); uPulse = u("uPulse"); uStar = u("uStar")
        uSun = u("uSun"); uAlt = u("uAlt"); uMoon = u("uMoon"); uShoot = u("uShoot")
        loadImage()
        makeNoise()
        texLights = loadTex(R.drawable.city_lights)
        texMoon = loadTex(R.drawable.moon_tex)
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        surfW = maxOf(width, 1); surfH = maxOf(height, 1)
        GLES20.glViewport(0, 0, surfW, surfH)
    }

    override fun onDrawFrame(gl: GL10?) {
        val t = (SystemClock.elapsedRealtime() - startMs) / 1000f

        // przycięcie obrazka tak, żeby wypełniał ekran (jak "cover")
        val sa = surfW.toFloat() / surfH
        val ia = imgW.toFloat() / imgH
        val cx = if (sa > ia) 1f else sa / ia
        val cy = if (sa > ia) ia / sa else 1f

        val flowA = (t / 420f) % 1f          // powolny dryf chmur (zapętla się bez skoku)
        val flowB = (t / 700f) % 1f          // jeszcze wolniejsze "falowanie" chmur
        val sweep = (t % 11f) / 5f           // 0..1 = przejście błysku, dalej przerwa
        val pulse = 0.5f + 0.5f * Math.sin(2.0 * Math.PI * (t % 9f) / 9f).toFloat()
        val star = (2.0 * Math.PI * ((t % 9f) / 9f)).toFloat()   // migotanie gwiazd
        updateSun()

        // spadająca gwiazda: co 25-70 s w losowym miejscu nieba, trwa ok. 0,9 s
        if (shootStart < 0f && t > nextShoot) {
            shootStart = t
            shootX = 0.08f + rnd.nextFloat() * 0.84f
            shootY = 0.04f + rnd.nextFloat() * 0.46f
            val a = Math.toRadians(15.0 + rnd.nextDouble() * 40.0).toFloat()
            shootAng = if (rnd.nextBoolean()) a else (Math.PI.toFloat() - a)
        }
        var prog = -1f
        if (shootStart >= 0f) {
            prog = (t - shootStart) / 0.9f
            if (prog > 1f) { shootStart = -1f; prog = -1f; nextShoot = t + 25f + rnd.nextFloat() * 45f }
        }

        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
        GLES20.glUseProgram(program)

        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texImage)
        GLES20.glUniform1i(uTex, 0)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE1)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texNoise)
        GLES20.glUniform1i(uNoise, 1)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE2)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texLights)
        GLES20.glUniform1i(uLights, 2)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE3)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texMoon)
        GLES20.glUniform1i(uMoonTex, 3)

        GLES20.glUniform2f(uTexel, 1f / imgW, 1f / imgH)
        GLES20.glUniform2f(uCover, cx, cy)
        GLES20.glUniform2f(uFlow, flowA, flowB)
        GLES20.glUniform1f(uSweep, sweep)
        GLES20.glUniform1f(uPulse, pulse)
        GLES20.glUniform2f(uSun, sunX, sunY)
        GLES20.glUniform1f(uAlt, sunAlt)
        GLES20.glUniform4f(uMoon, moonX, moonY, moonE, moonAlt)
        GLES20.glUniform1f(uStar, star)
        GLES20.glUniform4f(uShoot, shootX, shootY, shootAng, prog)

        GLES20.glEnableVertexAttribArray(aPos)
        GLES20.glVertexAttribPointer(aPos, 2, GLES20.GL_FLOAT, false, 0, quad)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        GLES20.glDisableVertexAttribArray(aPos)
    }

    /**
     * Słońce i Księżyc według prawdziwego zegara telefonu (okolice środka Polski, 52°N 19°E).
     * Wschód = prawa krawędź Ziemi, zachód = lewa. W nocy chowają się za Ziemią.
     * Faza Księżyca liczona z daty (miesiąc synodyczny).
     */
    private fun updateSun() {
        val now = SystemClock.elapsedRealtime()
        if (now - lastSunMs < 2000) return
        lastSunMs = now

        val cal = Calendar.getInstance()
        val tz = cal.timeZone.getOffset(cal.timeInMillis) / 3600000.0
        val hour = cal.get(Calendar.HOUR_OF_DAY) + cal.get(Calendar.MINUTE) / 60.0 +
            cal.get(Calendar.SECOND) / 3600.0
        val n = cal.get(Calendar.DAY_OF_YEAR)

        val lat = Math.toRadians(52.0)
        val lon = 19.0
        val decl = Math.toRadians(23.44) * Math.sin(2.0 * Math.PI * (n - 81) / 365.0)
        val noon = 12.0 + (15.0 * tz - lon) / 15.0

        // --- Słońce ---
        val c = (-Math.tan(lat) * Math.tan(decl)).coerceIn(-1.0, 1.0)
        val half = (Math.acos(c) * 12.0 / Math.PI).coerceIn(2.0, 10.0)  // pół dnia w godzinach
        var h = hour - noon
        while (h > 12.0) h -= 24.0
        while (h < -12.0) h += 24.0

        val alt = arcAlt(h, half)
        val pc = (h / half).coerceIn(-1.3, 1.3)
        val x = 0.5 - 0.38 * Math.sin(Math.PI / 2.0 * pc)
        val y = limbY(x) - 0.28 * alt
        sunX = x.toFloat(); sunY = y.toFloat(); sunAlt = alt.toFloat()

        // --- Księżyc ---
        val jd = System.currentTimeMillis() / 86400000.0 + 2440587.5
        var f = ((jd - 2451550.26) / 29.530588853) % 1.0
        if (f < 0) f += 1.0
        val e = 2.0 * Math.PI * f
        var hm = hour - noon - f * 24.84
        while (hm > 12.0) hm -= 24.0
        while (hm < -12.0) hm += 24.0
        val declM = decl * Math.cos(e)
        val cm = (-Math.tan(lat) * Math.tan(declM)).coerceIn(-1.0, 1.0)
        val halfM = (Math.acos(cm) * 12.0 / Math.PI).coerceIn(2.0, 10.0)
        val altM = arcAlt(hm, halfM)
        val pcM = (hm / halfM).coerceIn(-1.3, 1.3)
        val mx = 0.5 - 0.38 * Math.sin(Math.PI / 2.0 * pcM)
        moonX = mx.toFloat(); moonY = (limbY(mx) - 0.28 * altM).toFloat()
        moonE = e.toFloat(); moonAlt = altM.toFloat()
    }

    /** Wysokość nad horyzontem: cos w dzień, ujemna w nocy (h = godziny od górowania). */
    private fun arcAlt(h: Double, half: Double): Double =
        if (Math.abs(h) <= half) {
            Math.cos(Math.PI / 2.0 * h / half)
        } else {
            -Math.sin(Math.PI / 2.0 * (Math.abs(h) - half) / (12.0 - half))
        }

    private fun limbY(x: Double): Double = 0.708 + 0.769 * (x - 0.484) * (x - 0.484) - 0.05 * x

    private fun loadImage() {
        val opts = BitmapFactory.Options().apply { inScaled = false }
        val bmp = BitmapFactory.decodeResource(ctx.resources, R.drawable.wallpaper_base, opts)
        imgW = bmp.width; imgH = bmp.height
        val ids = IntArray(1)
        GLES20.glGenTextures(1, ids, 0)
        texImage = ids[0]
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texImage)
        setParams(GLES20.GL_CLAMP_TO_EDGE)
        GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bmp, 0)
        bmp.recycle()
    }

    private fun loadTex(res: Int): Int {
        val opts = BitmapFactory.Options().apply { inScaled = false }
        val bmp = BitmapFactory.decodeResource(ctx.resources, res, opts)
        val ids = IntArray(1)
        GLES20.glGenTextures(1, ids, 0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, ids[0])
        setParams(GLES20.GL_CLAMP_TO_EDGE)
        GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bmp, 0)
        bmp.recycle()
        return ids[0]
    }

    private fun setParams(wrap: Int) {
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, wrap)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, wrap)
    }

    /** Mała tekstura losowego szumu (64x64) - z niej powstają chmury i migotanie gwiazd. */
    private fun makeNoise() {
        val n = 64
        val data = ByteArray(n * n * 4)
        Random(7).nextBytes(data)
        val buf = ByteBuffer.allocateDirect(data.size).order(ByteOrder.nativeOrder())
        buf.put(data); buf.position(0)
        val ids = IntArray(1)
        GLES20.glGenTextures(1, ids, 0)
        texNoise = ids[0]
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texNoise)
        setParams(GLES20.GL_REPEAT)
        GLES20.glTexImage2D(GLES20.GL_TEXTURE_2D, 0, GLES20.GL_RGBA, n, n, 0,
            GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, buf)
    }

    private fun compile(type: Int, src: String): Int {
        val s = GLES20.glCreateShader(type)
        GLES20.glShaderSource(s, src)
        GLES20.glCompileShader(s)
        val ok = IntArray(1)
        GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0)
        if (ok[0] == 0) {
            val log = GLES20.glGetShaderInfoLog(s)
            GLES20.glDeleteShader(s)
            throw RuntimeException("Shader error: $log")
        }
        return s
    }

    private fun buildProgram(vs: String, fs: String): Int {
        val p = GLES20.glCreateProgram()
        GLES20.glAttachShader(p, compile(GLES20.GL_VERTEX_SHADER, vs))
        GLES20.glAttachShader(p, compile(GLES20.GL_FRAGMENT_SHADER, fs))
        GLES20.glLinkProgram(p)
        val ok = IntArray(1)
        GLES20.glGetProgramiv(p, GLES20.GL_LINK_STATUS, ok, 0)
        if (ok[0] == 0) throw RuntimeException("Link error: " + GLES20.glGetProgramInfoLog(p))
        return p
    }

    companion object {
        private const val VERTEX = """
attribute vec2 aPos;
uniform vec2 uCover;
varying vec2 vUv;
void main() {
    vec2 uv = vec2(aPos.x * 0.5 + 0.5, 0.5 - aPos.y * 0.5);
    vUv = (uv - 0.5) * uCover + 0.5;
    gl_Position = vec4(aPos, 0.0, 1.0);
}
"""

        private const val FRAGMENT = """
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif

uniform sampler2D uTex;
uniform sampler2D uNoise;
uniform sampler2D uLights;
uniform sampler2D uMoonTex;
uniform vec2 uTexel;
uniform vec2 uFlow;
uniform vec2 uSun;
uniform vec4 uMoon;      // x, y (uv), faza (rad), wysokość nad horyzontem
uniform float uAlt;
uniform float uSweep;
uniform float uPulse;
uniform float uStar;
uniform vec4 uShoot;
varying vec2 vUv;

const float AR = 1.7778;
const float MOON_R = 0.045;

float lumOf(vec3 c) { return dot(c, vec3(0.299, 0.587, 0.114)); }

float rectMask(vec2 uv, vec2 lo, vec2 hi) {
    vec2 a = smoothstep(lo - 0.01, lo + 0.01, uv);
    vec2 b = 1.0 - smoothstep(hi - 0.01, hi + 0.01, uv);
    return a.x * a.y * b.x * b.y;
}

void main() {
    vec2 uv = vUv;
    vec2 p = vec2(uv.x * AR, uv.y);
    vec2 sunP = vec2(uSun.x * AR, uSun.y);
    vec2 moonP = vec2(uMoon.x * AR, uMoon.y);

    float vis = smoothstep(-0.35, 0.05, uAlt);          // czy słońce świeci
    float dayBoost = smoothstep(-0.30, 0.10, uAlt);     // jak mocno oświetlona Ziemia
    float lowW = 1.0 - smoothstep(0.0, 0.55, uAlt);     // niskie słońce = pomarańczowe

    float mK = 0.5 - 0.5 * cos(uMoon.z);                // oświetlona część tarczy
    float moonVis = (1.0 - smoothstep(-0.05, 0.30, uAlt)) * smoothstep(-0.12, 0.06, uMoon.w);
    float mI = moonVis * (0.25 + 0.75 * mK);            // siła światła księżyca

    // --- krawędź Ziemi ---
    float yh = 0.708 + 0.769 * (uv.x - 0.484) * (uv.x - 0.484) - 0.05 * uv.x;
    float d = uv.y - yh;
    float earth = smoothstep(0.015, 0.075, d);

    vec3 col;
    if (earth > 0.0) {
        vec2 nc = vec2(p.x * 0.15, pow(max(d, 0.0), 0.6) * 1.35);
        vec2 w = texture2D(uNoise, nc * 0.5 + vec2(uFlow.y, 0.5)).gb - 0.5;
        vec3 n1 = texture2D(uNoise, nc + vec2(uFlow.x, 0.0)).rgb;
        vec3 n2 = texture2D(uNoise, nc * 2.0 + vec2(uFlow.x * 2.0, 0.0) + vec2(0.31, 0.17)).rgb;
        vec3 n3 = texture2D(uNoise, nc * 4.0 + vec2(uFlow.x * 4.0, 0.0) + vec2(0.62, 0.44)).rgb;
        vec3 f = n1 * 0.5 + n2 * 0.3 + n3 * 0.2;

        vec2 disp = (f.gb - 0.5) * 0.014 * earth;
        col = texture2D(uTex, uv + disp).rgb;

        // oświetlenie Ziemi słońcem
        float lightE = clamp(1.0 - abs(p.x - sunP.x) / 1.3, 0.0, 1.0);
        float lightK = lightE * dayBoost;
        float mulE = 0.28 + 0.85 * lightK;
        vec3 tint = mix(vec3(1.0), vec3(1.0, 0.80, 0.62), lowW * lightK);
        col *= mix(1.0, mulE, earth) * mix(vec3(1.0), tint, earth);

        // delikatna poświata księżyca na nocnej Ziemi
        float moonNear = exp(-abs(p.x - moonP.x) * 1.1);
        col *= 1.0 + earth * mI * moonNear * 0.5 * vec3(0.55, 0.75, 1.1);

        // chmury
        float c = f.r + w.x * 0.35;
        float cloud = smoothstep(0.50, 0.68, c) * earth;
        float lit = clamp(1.0 - distance(p, sunP) * 0.75, 0.0, 1.0) * dayBoost;
        vec3 cloudNight = vec3(0.10, 0.16, 0.30) + mI * moonNear * vec3(0.12, 0.17, 0.26);
        vec3 cloudCol = mix(cloudNight, mix(vec3(1.0, 0.95, 0.88), vec3(1.0, 0.78, 0.55), lowW), lit * lit);
        col = col * (1.0 - 0.30 * cloud) + cloudCol * cloud * 0.55;

        // światła miast na nocnej stronie Ziemi
        vec2 lc = vec2(p.x * 0.15 / 0.267, pow(max(d, 0.0), 0.6) * 1.35 / 0.66);
        vec3 Lc = texture2D(uLights, lc).rgb * 0.6
                + (texture2D(uLights, lc + vec2(0.004, 0.0)).rgb + texture2D(uLights, lc - vec2(0.004, 0.0)).rgb
                 + texture2D(uLights, lc + vec2(0.0, 0.010)).rgb + texture2D(uLights, lc - vec2(0.0, 0.010)).rgb) * 0.1;
        float nightK = 1.0 - smoothstep(0.05, 0.55, lightK);
        col += Lc * nightK * earth * (1.0 - 0.75 * cloud);
    } else {
        col = texture2D(uTex, uv).rgb;
    }

    float lum = lumOf(col);
    float region = max(rectMask(uv, vec2(0.385, 0.125), vec2(0.615, 0.46)),
                       rectMask(uv, vec2(0.17, 0.505), vec2(0.82, 0.605)));
    float chrome = region * smoothstep(0.18, 0.40, lum);

    // --- gwiazdy: od czasu do czasu któraś błyska ---
    float sky = 1.0 - smoothstep(-0.02, 0.0, d);
    float starMask = smoothstep(0.10, 0.30, lum) * sky * (1.0 - region);
    if (starMask > 0.0) {
        vec2 cell = floor(uv * vec2(160.0, 90.0));
        vec2 r = texture2D(uNoise, (mod(cell, 64.0) + 0.5) / 64.0).rg;
        float k = 1.0 + floor(r.g * 3.0);
        float tw = pow(0.5 + 0.5 * sin(r.r * 6.2832 + uStar * k), 6.0);
        float fct = 0.55 + 1.6 * tw;
        col = mix(col, col * fct, starMask);
    }

    // --- spadająca gwiazda ---
    if (uShoot.w >= 0.0 && sky > 0.0) {
        float pr = uShoot.w;
        vec2 dir = vec2(cos(uShoot.z), sin(uShoot.z));
        vec2 s0 = vec2(uShoot.x * AR, uShoot.y);
        vec2 head = s0 + dir * 0.42 * pr;
        vec2 tail = head - dir * 0.16 * min(pr * 4.0, 1.0);
        vec2 ba = head - tail;
        float bl = dot(ba, ba) + 0.000001;
        float hh = clamp(dot(p - tail, ba) / bl, 0.0, 1.0);
        float dd = length(p - tail - ba * hh) / 0.0022;
        float env = smoothstep(0.0, 0.12, pr) * (1.0 - smoothstep(0.65, 1.0, pr));
        if (dd < 6.0) {
            float it = exp(-dd * dd * 0.5) * hh * hh;
            col += vec3(0.85, 0.92, 1.0) * it * env * sky * (1.0 - 0.8 * chrome);
        }
    }

    // --- atmosfera przy krawędzi ---
    float band = exp(-abs(d) * 45.0);
    float warmness = clamp((col.r - col.b) * 3.0, 0.0, 1.0);
    float keep = vis * exp(-abs(p.x - sunP.x) * 2.5);
    vec3 cool = vec3(lum) * vec3(0.80, 0.92, 1.15);
    col = mix(col, cool, warmness * band * (1.0 - keep) * 0.85);
    col += mix(vec3(1.0, 0.78, 0.52), vec3(1.0, 0.40, 0.14), lowW)
         * exp(-abs(d) * 60.0) * exp(-abs(p.x - sunP.x) * 3.0) * vis * 0.45;
    col += vec3(0.55, 0.70, 1.0) * exp(-abs(d) * 60.0) * exp(-abs(p.x - moonP.x) * 3.0) * mI * 0.25;

    // --- słońce (za chromem): kolor i rozmiar zmieniają się w ciągu dnia ---
    vec2 q = p - sunP;
    float ds = length(q);
    float a = clamp(uAlt, 0.0, 1.0);
    vec3 sunC = mix(vec3(1.0, 0.30, 0.06), vec3(1.0, 0.62, 0.28), smoothstep(0.0, 0.15, a));
    sunC = mix(sunC, vec3(1.0, 0.90, 0.70), smoothstep(0.12, 0.45, a));
    sunC = mix(sunC, vec3(1.0, 0.97, 0.93), smoothstep(0.40, 0.90, a));
    vec3 coreC = mix(vec3(1.0, 0.72, 0.38), vec3(1.0, 0.98, 0.95), smoothstep(0.0, 0.35, a));
    float rad = mix(0.026, 0.017, smoothstep(0.0, 0.6, a));
    float disc = 1.0 - smoothstep(rad * 0.72, rad, ds);
    float core = exp(-ds * 22.0) * 0.8;
    float haloN = exp(-ds * 7.0) * 0.55;
    float haloW = exp(-ds * 2.2) * (0.20 + 0.10 * (1.0 - a));
    float lowGlow = exp(-ds * 4.0) * 0.5 * (1.0 - smoothstep(0.0, 0.4, a));
    float spread = mix(1.0, 0.6, smoothstep(0.3, 1.0, uAlt));
    vec3 glow = coreC * (disc * 1.6 + core)
              + sunC * ((haloN + lowGlow) * 0.9 + haloW) * spread * (0.96 + 0.04 * uPulse);
    float haze = exp(-abs(p.x - sunP.x) * 3.0) * exp(-max(-d, 0.0) * 14.0) * lowW * 0.22;
    glow += sunC * haze;
    float skyW = 1.0 - smoothstep(-0.006, 0.004, d);   // Ziemia zasłania niebo
    col += glow * skyW * vis * (1.0 - 0.9 * chrome);

    // --- księżyc z prawdziwą fazą (za chromem, zasłaniany przez Ziemię) ---
    vec2 mq = (p - moonP) / MOON_R;
    float mr = length(mq);
    if (moonVis > 0.0 && mr < 4.0) {
        float kM = skyW * moonVis * (1.0 - 0.9 * chrome);
        // delikatna łuna wokół tarczy
        col += vec3(0.55, 0.66, 0.90) * (exp(-mr * 1.8) * 0.06 + exp(-mr * 0.6) * 0.02) * (0.2 + 0.8 * mK) * kM;
        if (mr < 1.05) {
            float mz = sqrt(max(1.0 - min(mr * mr, 1.0), 0.0));
            vec2 muv = mq * 0.5 + 0.5;
            float alb = texture2D(uMoonTex, muv).r;
            float hx = texture2D(uMoonTex, muv + vec2(0.006, 0.0)).g - texture2D(uMoonTex, muv - vec2(0.006, 0.0)).g;
            float hy = texture2D(uMoonTex, muv + vec2(0.0, 0.006)).g - texture2D(uMoonTex, muv - vec2(0.0, 0.006)).g;
            vec3 mn = normalize(vec3(mq.x - hx * 2.2, -mq.y + hy * 2.2, max(mz, 0.02)));
            vec3 sdir = vec3(sin(uMoon.z), 0.0, -cos(uMoon.z));
            float mu0 = dot(mn, sdir);
            float mL = 0.0;
            if (mu0 > 0.0) mL = mu0 / (mu0 + max(mz, 0.02)) * 2.0 * clamp(mu0 / 0.06, 0.0, 1.0);
            float mc = alb * (mL + 0.035 * (1.0 - mK)) * 1.25;
            vec3 mtint = mix(vec3(1.0, 0.74, 0.48), vec3(1.0, 0.99, 0.95), smoothstep(0.0, 0.30, uMoon.w));
            float medge = 1.0 - smoothstep(0.95, 1.0, mr);
            col = mix(col, vec3(mc) * mtint, medge * kM);
        }
    }

    // --- światło na chromowanym logo i napisie ---
    if (chrome > 0.0) {
        vec2 t2 = uTexel * 2.0;
        float lx1 = lumOf(texture2D(uTex, uv + vec2(t2.x, 0.0)).rgb);
        float lx2 = lumOf(texture2D(uTex, uv - vec2(t2.x, 0.0)).rgb);
        float ly1 = lumOf(texture2D(uTex, uv + vec2(0.0, t2.y)).rgb);
        float ly2 = lumOf(texture2D(uTex, uv - vec2(0.0, t2.y)).rgb);
        vec3 N = normalize(vec3((lx2 - lx1) * 3.0, (ly2 - ly1) * 3.0, 0.6));

        // słońce
        vec3 L = normalize(vec3((sunP - p), 0.30 + 0.25 * uPulse));
        vec3 H = normalize(L + vec3(0.0, 0.0, 1.0));
        float spec = pow(max(dot(N, H), 0.0), 16.0);
        float dif = max(dot(N, L), 0.0);

        float warmL = clamp(1.0 - distance(p, sunP) * 0.8, 0.0, 1.0);
        vec3 lcol = mix(vec3(1.0, 0.95, 0.88), vec3(1.0, 0.55, 0.25), max(warmL * 0.6, lowW));

        float s = dot(p, vec2(-0.94, 0.34));
        float pos = mix(-1.55, 0.25, uSweep);
        float x = (s - pos) / 0.07;
        float bnd = exp(-x * x);

        vec3 add = (spec * 0.9 + dif * 0.10 * (0.8 + 0.2 * uPulse)) * lcol
                 + bnd * (0.35 + lum) * vec3(1.0, 0.88, 0.70) * 0.85;
        col += chrome * add * vis;
        col += chrome * warmL * lum * 0.18 * vec3(1.0, 0.5, 0.2) * vis;

        // chłodny odblask księżyca (słabszy przy cienkim sierpie)
        float moonRef = moonVis * mK;
        if (moonRef > 0.01) {
            vec3 Lm = normalize(vec3(moonP - p, 0.35));
            vec3 Hm = normalize(Lm + vec3(0.0, 0.0, 1.0));
            float specM = pow(max(dot(N, Hm), 0.0), 18.0);
            float difM = max(dot(N, Lm), 0.0);
            col += chrome * (specM * 0.55 + difM * 0.07) * vec3(0.70, 0.82, 1.0) * moonRef;
        }
    }

    gl_FragColor = vec4(col, 1.0);
}
"""
    }
}
