package pl.honda.wallpaper

import android.opengl.GLSurfaceView
import android.os.Handler
import android.os.Looper
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder

class HondaWallpaperService : WallpaperService() {

    override fun onCreateEngine(): Engine = HondaEngine()

    inner class HondaEngine : Engine() {
        private var glView: GlView? = null
        private val handler = Handler(Looper.getMainLooper())
        private var running = false
        private val frameMs = 33L // ok. 30 klatek/s - lżej dla tabletu

        private val tick = object : Runnable {
            override fun run() {
                if (!running) return
                glView?.requestRender()
                handler.postDelayed(this, frameMs)
            }
        }

        inner class GlView : GLSurfaceView(this@HondaWallpaperService) {
            override fun getHolder(): SurfaceHolder = this@HondaEngine.surfaceHolder
            fun destroyView() { super.onDetachedFromWindow() }
        }

        override fun onCreate(surfaceHolder: SurfaceHolder) {
            super.onCreate(surfaceHolder)
            val v = GlView()
            v.setEGLContextClientVersion(2)
            v.setRenderer(HondaRenderer(applicationContext))
            v.renderMode = GLSurfaceView.RENDERMODE_WHEN_DIRTY
            glView = v
        }

        override fun onVisibilityChanged(visible: Boolean) {
            super.onVisibilityChanged(visible)
            if (visible) {
                glView?.onResume()
                running = true
                handler.post(tick)
            } else {
                running = false
                handler.removeCallbacks(tick)
                glView?.onPause()
            }
        }

        override fun onDestroy() {
            running = false
            handler.removeCallbacks(tick)
            glView?.destroyView()
            glView = null
            super.onDestroy()
        }
    }
}
