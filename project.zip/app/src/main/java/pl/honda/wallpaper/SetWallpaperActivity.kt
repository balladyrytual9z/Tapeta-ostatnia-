package pl.honda.wallpaper

import android.app.Activity
import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.widget.Toast

/** Po otwarciu apki od razu pokazuje ekran ustawiania tapety. */
class SetWallpaperActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val component = ComponentName(this, HondaWallpaperService::class.java)

        val direct = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER)
            .putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT, component)
        val chooser = Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER)

        val ok = tryStart(direct) || tryStart(chooser)
        if (!ok) {
            Toast.makeText(
                this,
                "Ten system nie ma wyboru tapet na żywo. Użyj tapety w swoim launcherze.",
                Toast.LENGTH_LONG
            ).show()
        }
        finish()
    }

    private fun tryStart(i: Intent): Boolean = try {
        startActivity(i); true
    } catch (e: Exception) {
        false
    }
}
